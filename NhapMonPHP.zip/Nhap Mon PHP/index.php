<?php
   $tenhinh = "tho.jpg";
   $width = "150px";
   $height = "100px";
?>
<html>
<head>
    <title> So yeu Ly Lich</title>
</head>
<body>
    
    <h1> Sơ yếu lý lịch</h1>
    <!-- <h2>Sơ yếu lý lịch</h2>
    <h3>Sơ yếu lý lịch</h3>
    <h4>Sơ yếu lý lịch</h4>
    <h5>Sơ yếu lý lịch</h5>
    <h6>Sơ yếu lý lịch</h6> -->
    <img src="image/<?php echo $tenhinh;?>" width="<?php echo $width?>" height = <?php echo $height?> alt="cafe" >
    <p></p>
     Ten : <p> Phong</p>
     Tuoi : <p> 18+</p>
     Giới Tính : <p> Nam</p>
    <?php
    echo "<table border="."1".">";
    echo "<tr>";
    echo "<td>";
        echo "1";
    echo "</td>";
    echo "<td>";
    echo "1";
    echo "</td>";
    echo "<td>";
    echo "1";
    echo "</td>";	
    echo "</tr>";
    echo "<tr>";
    echo "<td>";
    echo "</td>";
    echo "<td>";
    echo "</td>";
    echo "<td>";
    echo "</td>";	
    echo "</tr>";
    echo "<tr>";
    echo "<td>";
    echo "</td>";
    echo "<td>";
    echo "</td>";
    echo "<td>";
    echo "</td>";	
    echo "</tr>"; 
    echo "</table>";
    ?>

</body>


</html>
